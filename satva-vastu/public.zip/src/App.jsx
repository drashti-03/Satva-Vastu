//import { useState } from "react";
import Header from "./components/Header/Header";
import Hero from "./components/Hero/Hero";
import "./App.css";
import VastuInfo from "./components/VastuInfo/VastuInfo";
import Satva from "./components/SatvaMeaning/Satva";

function App() {
  return (
    <>
      <Header></Header>
      <Hero></Hero>
      <VastuInfo></VastuInfo>
      <Satva></Satva>
    </>
  );
}

export default App;
